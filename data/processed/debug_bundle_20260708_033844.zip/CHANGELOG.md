# Changelog

## v16 - Full project fleshing package

- Added Python SDK client.
- Added project validation script.
- Added generated project inventory script.
- Added data dictionary, environment reference, configuration reference.
- Added Mermaid diagrams for system context, deployment layers, and data flow.
- Added production, source onboarding, and release checklists.

## v15

- Added README files to every project folder.

## v14 and earlier

See README sections for historical build-up: scraping, Google Trends, formulas, ML, reports, API, deployment, production layers, testing, and storage.

## v20

- Reworked Streamlit UI into modern flat dark design.
- Applied black background and earthy color palette.
- Removed emojis and emoticons from text files.
- Removed em dash characters from text files.
- Added `.streamlit/config.toml` theme.
- Added UI style guide in `docs/ui/README.md`.

## v21

- Added root-level one-click Windows start and stop files.
- Added root-level Linux start and stop scripts.
- Added Podman Windows start file.
- Added desktop shortcut creator for Windows.
- Added Start Here markdown and HTML guide.

## v22

- Added diagnostics page in Streamlit.
- Added command-line doctor script.
- Added Windows check and fix launcher.
- Split Windows setup into reusable setup script.
- Fixed Windows dashboard plus API launcher flow.
- Added debug documentation.

## v23

- Fixed doctor JSON mode.
- Fixed remaining active old runtime references.
- Fixed chaos drill to use Podman Compose.
- Fixed Windows portable package file list.
- Added text policy and runtime reference audit scripts.

## v24

- Added debug bundle generator.
- Added self-repair workflow.
- Added dependency report and port report scripts.
- Added recent log viewer in Diagnostics page.
- Added Windows repair and dependency report launchers.
- Fixed project inventory UTC deprecation warning.
